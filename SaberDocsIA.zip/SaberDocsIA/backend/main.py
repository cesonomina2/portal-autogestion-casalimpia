"""
main.py — FastAPI: punto de entrada del backend de Instructivos IA
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import settings
from routers import process, history

app = FastAPI(
    title="Instructivos IA — Backend",
    version="1.0.0",
    description="API de procesamiento de grabaciones de pantalla para generación de instructivos",
)

# ── CORS (permite llamadas desde el frontend local o corporativo) ──────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ────────────────────────────────────────────────────────────
app.include_router(process.router, prefix="/api")
app.include_router(history.router, prefix="/api")


# ── Health check (usado por el frontend para detectar modo REAL) ───────
@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


# ── Estado de APIs externas ────────────────────────────────────────────
@app.get("/api/status")
async def api_status():
    """
    Verifica la disponibilidad de cada API externa.
    En modo stub retorna todo como False hasta que las APIs estén configuradas.
    """
    from services.stt_service     import check_stt_connection
    from services.ai_service      import check_ai_connection
    from services.docs_service    import check_docs_connection

    return JSONResponse({
        "google_stt":        await check_stt_connection(),
        "claude":            await check_ai_connection(),
        "google_workspace":  await check_docs_connection(),
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
