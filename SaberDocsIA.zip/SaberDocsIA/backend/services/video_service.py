"""
video_service.py — Extracción de frames y audio del video
Stub: retorna datos vacíos hasta que FFmpeg esté disponible en el servidor.
"""
import tempfile
import os
from typing import Any


async def extract_frames_and_audio(video_bytes: bytes, filename: str) -> tuple[list[Any], str]:
    """
    Extrae fotogramas clave y el audio de un video.

    Retorna:
        frames    : lista de rutas de imagen (PNG)
        audio_path: ruta del archivo WAV extraído

    Implementación real requiere:
        - ffmpeg en PATH del servidor
        - Dependencia: ffmpeg-python, opencv-python
    """
    # ── Stub ─────────────────────────────────────────────────────────
    # Guarda el video en un directorio temporal
    tmp_dir = tempfile.mkdtemp(prefix="instructivos_")
    video_path = os.path.join(tmp_dir, filename)

    with open(video_path, "wb") as f:
        f.write(video_bytes)

    # TODO: reemplazar con extracción real usando FFmpeg
    # import ffmpeg
    # audio_path = os.path.join(tmp_dir, "audio.wav")
    # ffmpeg.input(video_path).output(audio_path, ac=1, ar=16000).run(quiet=True, overwrite_output=True)
    # frames = _extract_key_frames(video_path, tmp_dir)

    audio_path = ""  # stub
    frames = []      # stub

    return frames, audio_path


def _extract_key_frames(video_path: str, output_dir: str, fps: float = 0.5) -> list[str]:
    """Extrae un frame cada 2 segundos usando OpenCV."""
    # import cv2
    # cap = cv2.VideoCapture(video_path)
    # ...
    return []
