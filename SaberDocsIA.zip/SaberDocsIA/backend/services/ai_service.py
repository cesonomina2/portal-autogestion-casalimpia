"""
ai_service.py — Generación del instructivo con Claude (Anthropic)
Stub: retorna estructura vacía hasta que ANTHROPIC_API_KEY esté configurada.
"""
from config import settings

SYSTEM_PROMPT = """
Eres un experto en redacción de instructivos técnicos para la empresa Casalimpia.
Tu tarea es convertir una transcripción de audio de una grabación de pantalla en un instructivo
paso a paso, siguiendo estas reglas:
1. Usa el modo imperativo formal en español colombiano ("Ingrese", "Seleccione", "Haga clic").
2. Cada paso debe tener máximo 3 líneas.
3. Si un segmento tiene baja confianza, agrega la nota "⚠️ Validar paso".
4. Los campos del encabezado (código, vigencia) siempre deben quedar como "[PENDIENTE — Área de Procesos]".
5. Devuelve únicamente JSON con el esquema indicado.

Esquema de salida:
{
  "titulo": "string",
  "objetivo": "string",
  "pasos": [
    {"numero": 1, "titulo": "string", "descripcion": "string", "nota": "string|null"}
  ],
  "advertencias": 0
}
"""


async def generate_instructivo(transcript: dict, metadata: dict, frames: list) -> dict:
    """
    Llama a Claude para generar el instructivo a partir de la transcripción.

    Implementación real requiere:
        - ANTHROPIC_API_KEY configurada
        - Dependencia: anthropic==0.28.0
    """
    if not settings.ANTHROPIC_API_KEY:
        return _empty_instructivo(metadata)

    # TODO: reemplazar con llamada real
    # import anthropic
    # client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    # response = client.messages.create(
    #     model=settings.CLAUDE_MODEL,
    #     max_tokens=4096,
    #     temperature=0,
    #     system=SYSTEM_PROMPT,
    #     messages=[{
    #         "role": "user",
    #         "content": f"Proceso: {metadata['proceso']}\n\nTranscripción:\n{transcript['texto_completo']}"
    #     }]
    # )
    # return json.loads(response.content[0].text)

    return _empty_instructivo(metadata)


async def check_ai_connection() -> bool:
    """Verifica que la API key de Anthropic sea válida."""
    if not settings.ANTHROPIC_API_KEY:
        return False
    try:
        # import anthropic
        # client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        # client.models.list()
        return False  # stub
    except Exception:
        return False


def _empty_instructivo(metadata: dict) -> dict:
    return {
        "titulo": f"Instructivo: {metadata.get('proceso', '')}",
        "objetivo": "",
        "pasos": [],
        "advertencias": 0,
    }
