"""
stt_service.py — Transcripción con Google Cloud Speech-to-Text
Stub: retorna transcripción vacía hasta que las credenciales estén configuradas.
"""
from config import settings

STT_CONFIDENCE_THRESHOLD = settings.STT_CONFIDENCE_THRESHOLD


async def transcribe(audio_path: str) -> dict:
    """
    Envía el audio a Google STT y retorna la transcripción segmentada.

    Retorna:
        {
          "texto_completo": str,
          "segmentos": [{"texto": str, "confianza": float, "inicio": float, "fin": float}],
          "confianza_promedio": float,
        }

    Implementación real requiere:
        - GOOGLE_APPLICATION_CREDENTIALS apuntando al JSON de la cuenta de servicio
        - Rol: roles/speech.client
        - Dependencia: google-cloud-speech==2.26.0
    """
    if not audio_path:
        return _empty_transcript()

    # TODO: reemplazar con llamada real
    # from google.cloud import speech
    # client = speech.SpeechClient()
    # with open(audio_path, "rb") as f:
    #     content = f.read()
    # audio   = speech.RecognitionAudio(content=content)
    # config  = speech.RecognitionConfig(
    #     encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
    #     sample_rate_hertz=16000,
    #     language_code="es-CO",
    #     model="latest_long",
    #     enable_word_time_offsets=True,
    # )
    # response = client.recognize(config=config, audio=audio)
    # ...

    return _empty_transcript()


async def check_stt_connection() -> bool:
    """Verifica que las credenciales STT sean válidas (ping con silencio PCM)."""
    if not settings.GOOGLE_APPLICATION_CREDENTIALS:
        return False
    try:
        # from google.cloud import speech
        # client = speech.SpeechClient()
        # ... ping con 1 segundo de silencio ...
        return False  # stub
    except Exception:
        return False


def _empty_transcript() -> dict:
    return {"texto_completo": "", "segmentos": [], "confianza_promedio": 0.0}


def _label_low_confidence(segmentos: list) -> list:
    """Marca segmentos con baja confianza con la etiqueta de validación."""
    result = []
    for seg in segmentos:
        if seg["confianza"] < STT_CONFIDENCE_THRESHOLD:
            seg["texto"] = "[Texto pendiente de validación — audio no claro]"
        result.append(seg)
    return result
