"""
docs_service.py — Integración con Google Workspace (Docs, Slides, Drive, Sheets)
Stub: retorna valores vacíos hasta que las credenciales estén configuradas.
"""
from typing import Optional
from config import settings

GOOGLE_WORKSPACE_DOMAIN = settings.GOOGLE_WORKSPACE_DOMAIN


# ── Google Docs ────────────────────────────────────────────────────────

async def create_google_doc(instructivo_data: dict, frames: list) -> tuple[str, str, dict]:
    """
    Crea un Google Doc con el instructivo e inserta imágenes subidas a Drive.

    Retorna:
        doc_id    : ID del documento en Google Docs
        doc_url   : URL pública restringida al dominio corporativo
        frame_urls: { paso_numero: url_imagen }

    Implementación real requiere:
        - GOOGLE_APPLICATION_CREDENTIALS con roles: roles/docs.editor, roles/drive.file
        - Dependencias: google-api-python-client, google-auth
    """
    # TODO:
    # from googleapiclient.discovery import build
    # from google.oauth2 import service_account
    # creds = service_account.Credentials.from_service_account_file(
    #     settings.GOOGLE_APPLICATION_CREDENTIALS,
    #     scopes=["https://www.googleapis.com/auth/documents", "https://www.googleapis.com/auth/drive"]
    # )
    # docs  = build("docs",  "v1", credentials=creds)
    # drive = build("drive", "v3", credentials=creds)
    # ...
    return "", "", {}


async def create_google_slides(instructivo_data: dict, frame_urls: dict) -> Optional[str]:
    """
    Crea una presentación en Google Slides con portada, objetivo y un slide por paso.

    Implementación real requiere:
        - roles/slides.editor
    """
    # TODO:
    # from googleapiclient.discovery import build
    # slides = build("slides", "v1", credentials=creds)
    # ...
    return None


# ── Google Sheets ──────────────────────────────────────────────────────

async def register_in_history(instructivo_data: dict, doc_url: str, metadata: dict) -> None:
    """
    Agrega una fila al Google Sheet de historial con los datos del instructivo.
    Columnas: Fecha, Código, Proceso, Área, Versión, Duración (min), Pasos, URL Doc.
    """
    # TODO:
    # sheets = build("sheets", "v4", credentials=creds)
    # sheets.spreadsheets().values().append(...)
    pass


async def get_history_from_sheets() -> list[dict]:
    """Lee el historial desde Google Sheets y retorna lista de dicts."""
    # TODO:
    # sheets = build("sheets", "v4", credentials=creds)
    # result = sheets.spreadsheets().values().get(...).execute()
    # ...
    return []


# ── Helpers ────────────────────────────────────────────────────────────

async def check_docs_connection() -> bool:
    """Verifica que las credenciales de Google Workspace sean válidas."""
    if not settings.GOOGLE_APPLICATION_CREDENTIALS:
        return False
    try:
        # from google.oauth2 import service_account
        # creds = service_account.Credentials.from_service_account_file(...)
        # drive = build("drive", "v3", credentials=creds)
        # drive.files().list(pageSize=1).execute()
        return False  # stub
    except Exception:
        return False


async def _upload_image_to_drive(image_path: str, drive_client, folder_id: str) -> str:
    """Sube una imagen a Drive y devuelve su URL. Permisos: dominio corporativo."""
    # from googleapiclient.http import MediaFileUpload
    # file_metadata = {"name": os.path.basename(image_path), "parents": [folder_id]}
    # media = MediaFileUpload(image_path, mimetype="image/png")
    # file = drive_client.files().create(body=file_metadata, media_body=media, fields="id").execute()
    # drive_client.permissions().create(
    #     fileId=file["id"],
    #     body={"type": "domain", "role": "reader", "domain": GOOGLE_WORKSPACE_DOMAIN}
    # ).execute()
    # return f"https://drive.google.com/uc?id={file['id']}"
    return ""
