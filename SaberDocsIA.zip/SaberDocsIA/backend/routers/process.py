"""
process.py — Endpoints de procesamiento de video
  POST /api/process          → inicia el pipeline, retorna task_id
  GET  /api/process/{task_id} → estado actual de la tarea
"""
import asyncio
import uuid
from typing import Optional

from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse

from config import settings
from services import video_service, stt_service, ai_service, docs_service

router = APIRouter()

# Almacén en memoria de tareas (reemplazar por Redis o DB en producción)
_tasks: dict[str, dict] = {}


@router.post("/process")
async def start_process(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(..., description="Archivo de video MP4/AVI/MOV/MKV"),
    proceso: str = Form(...),
    area: str = Form(...),
    version: str = Form("1.0"),
    includeSlides: str = Form("0"),
):
    """Recibe el video y lanza el pipeline en background. Retorna task_id inmediatamente."""

    # Validaciones básicas
    allowed_types = {"video/mp4", "video/x-msvideo", "video/quicktime", "video/x-matroska"}
    if video.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Formato de video no admitido")

    task_id = str(uuid.uuid4())
    _tasks[task_id] = {
        "status": "pending",
        "stage": 0,
        "progress": 0,
        "overall_progress": 0,
        "result": None,
        "message": "",
    }

    background_tasks.add_task(
        _run_pipeline,
        task_id=task_id,
        video_bytes=await video.read(),
        filename=video.filename or "video.mp4",
        metadata={
            "proceso": proceso,
            "area": area,
            "version": version,
            "includeSlides": includeSlides == "1",
        },
    )

    return JSONResponse({"task_id": task_id, "status": "pending"})


@router.get("/process/{task_id}")
async def get_task_status(task_id: str):
    task = _tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Tarea no encontrada")
    return JSONResponse(task)


# ── Pipeline completo ──────────────────────────────────────────────────
async def _run_pipeline(task_id: str, video_bytes: bytes, filename: str, metadata: dict):
    def update(stage: int, progress: int, overall: int, status: str = "processing"):
        _tasks[task_id].update({
            "status": status,
            "stage": stage,
            "progress": progress,
            "overall_progress": overall,
        })

    try:
        # Etapa 0: Extracción de frames y audio
        update(0, 0, 0)
        frames, audio_path = await video_service.extract_frames_and_audio(video_bytes, filename)
        update(0, 100, 17)

        # Etapa 1: Transcripción Google STT
        update(1, 0, 17)
        transcript = await stt_service.transcribe(audio_path)
        update(1, 100, 33)

        # Etapa 2: Generación de instructivo con Claude
        update(2, 0, 33)
        instructivo_data = await ai_service.generate_instructivo(transcript, metadata, frames)
        update(2, 100, 50)

        # Etapa 3: Creación Google Doc
        update(3, 0, 50)
        doc_id, doc_url, frame_urls = await docs_service.create_google_doc(instructivo_data, frames)
        update(3, 100, 67)

        # Etapa 4: Presentación Google Slides (opcional)
        slides_url: Optional[str] = None
        if metadata.get("includeSlides"):
            update(4, 0, 67)
            slides_url = await docs_service.create_google_slides(instructivo_data, frame_urls)
            update(4, 100, 83)
        else:
            update(4, 100, 83)

        # Etapa 5: Registro en historial (Google Sheets)
        update(5, 0, 83)
        await docs_service.register_in_history(instructivo_data, doc_url, metadata)
        update(5, 100, 100)

        _tasks[task_id]["status"] = "done"
        _tasks[task_id]["result"] = {
            "doc_url": doc_url,
            "slides_url": slides_url,
            "steps": instructivo_data.get("pasos", []),
            "stats": {
                "pasos": len(instructivo_data.get("pasos", [])),
                "confianza_stt": transcript.get("confianza_promedio", 0),
                "advertencias": instructivo_data.get("advertencias", 0),
                "duracion_proceso": 0,
            },
        }

    except Exception as exc:
        _tasks[task_id]["status"] = "error"
        _tasks[task_id]["message"] = str(exc)
