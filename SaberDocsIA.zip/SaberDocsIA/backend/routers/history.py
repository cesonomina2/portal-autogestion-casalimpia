"""
history.py — Endpoints del historial de instructivos
  GET  /api/history → lista de instructivos generados
  POST /api/history → agregar entrada manualmente (uso interno)
"""
from fastapi import APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional

router = APIRouter()


class HistoryEntry(BaseModel):
    proceso: str
    area: str
    fecha: str
    duracion: str
    pasos: int
    estado: str = "Pendiente nomenclatura"
    doc_url: Optional[str] = None


@router.get("/history")
async def get_history():
    """
    Retorna el historial desde Google Sheets.
    Stub: retorna lista vacía hasta que docs_service esté configurado.
    """
    try:
        from services.docs_service import get_history_from_sheets
        entries = await get_history_from_sheets()
        return JSONResponse(entries)
    except Exception:
        return JSONResponse([])


@router.post("/history")
async def add_history_entry(entry: HistoryEntry):
    """Agrega una entrada al historial (normalmente llamado internamente por el pipeline)."""
    try:
        from services.docs_service import register_in_history
        await register_in_history(entry.model_dump(), entry.doc_url or "", {})
        return JSONResponse({"status": "ok"})
    except Exception as exc:
        return JSONResponse({"status": "error", "detail": str(exc)}, status_code=500)
