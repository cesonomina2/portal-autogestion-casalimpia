"""
config.py — Variables de entorno y configuración central
Crea un archivo .env en esta carpeta para configurar las claves de API.
"""
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # ── Google Cloud ──────────────────────────────────────────────────
    GOOGLE_APPLICATION_CREDENTIALS: str = Field("", description="Ruta al JSON de la cuenta de servicio")
    GOOGLE_WORKSPACE_DOMAIN: str = Field("casalimpia.com.co")
    GOOGLE_DRIVE_FOLDER_ID: str = Field("", description="ID de la carpeta raíz en Drive")
    GOOGLE_SHEETS_HISTORY_ID: str = Field("", description="ID de la hoja de historial")

    # ── Anthropic / Claude ────────────────────────────────────────────
    ANTHROPIC_API_KEY: str = Field("", description="Clave API de Anthropic")
    CLAUDE_MODEL: str = Field("claude-sonnet-4-6")

    # ── Procesamiento de video ────────────────────────────────────────
    MAX_VIDEO_MB: int = Field(500)
    MAX_VIDEO_SECONDS: int = Field(1800)  # 30 min
    STT_CONFIDENCE_THRESHOLD: float = Field(0.70)
    FRAMES_PER_STEP: int = Field(1)

    # ── Servidor ──────────────────────────────────────────────────────
    ALLOWED_ORIGINS: list[str] = Field(default=["*"])
    UPLOAD_DIR: str = Field("/tmp/instructivos_uploads")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
