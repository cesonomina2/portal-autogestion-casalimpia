/* ═══════════════════════════════════════════════════════════════════════
   api.js — Cliente HTTP con detección automática de modo DEMO/REAL
   ═══════════════════════════════════════════════════════════════════════ */

const API = (() => {

  let _backendUrl  = 'http://localhost:8000';
  let _isRealMode  = false;
  let _checkDone   = false;

  /* ── Configuración ───────────────────────────────────────────────── */
  function setBackendUrl(url) {
    _backendUrl = url.replace(/\/$/, '');
    _checkDone  = false;
  }

  function isRealMode() { return _isRealMode; }

  /* ── Detección de backend ────────────────────────────────────────── */
  async function detectMode() {
    if (_checkDone) return _isRealMode;
    try {
      const res = await fetch(`${_backendUrl}/api/health`, {
        method: 'GET',
        signal: AbortSignal.timeout(3000),
      });
      _isRealMode = res.ok;
    } catch {
      _isRealMode = false;
    }
    _checkDone = true;
    return _isRealMode;
  }

  /* ── Función genérica de fetch con reintentos ────────────────────── */
  async function request(path, options = {}, retries = 2) {
    const url = `${_backendUrl}${path}`;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(url, {
          headers: { 'Content-Type': 'application/json', ...options.headers },
          ...options,
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
      } catch (err) {
        if (attempt === retries) throw err;
        await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
      }
    }
  }

  /* ── Endpoints reales (backend FastAPI) ──────────────────────────── */

  /**
   * POST /api/process
   * FormData con: video (File), proceso, area, version, includeSlides
   * Retorna: { task_id, status }
   */
  async function submitVideo(formData) {
    const url = `${_backendUrl}/api/process`;
    const res = await fetch(url, {
      method: 'POST',
      body: formData,   // multipart, sin Content-Type header (el browser lo pone)
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  /**
   * GET /api/process/:taskId
   * Retorna: { status, stage, progress, result? }
   */
  async function getTaskStatus(taskId) {
    return request(`/api/process/${taskId}`);
  }

  /**
   * GET /api/history
   * Retorna: [ { id, proceso, area, fecha, duracion, pasos, estado, doc_url } ]
   */
  async function getHistory() {
    return request('/api/history');
  }

  /**
   * GET /api/status
   * Retorna: { google_stt, claude, google_workspace }
   */
  async function getApiStatus() {
    return request('/api/status');
  }

  /* ── Polling para tareas largas ──────────────────────────────────── */
  async function pollTask(taskId, onProgress, intervalMs = 2000) {
    return new Promise((resolve, reject) => {
      const timer = setInterval(async () => {
        try {
          const data = await getTaskStatus(taskId);
          if (typeof onProgress === 'function') onProgress(data);
          if (data.status === 'done') {
            clearInterval(timer);
            resolve(data.result);
          } else if (data.status === 'error') {
            clearInterval(timer);
            reject(new Error(data.message || 'Error en el servidor'));
          }
        } catch (err) {
          clearInterval(timer);
          reject(err);
        }
      }, intervalMs);
    });
  }

  return {
    setBackendUrl,
    isRealMode,
    detectMode,
    submitVideo,
    getTaskStatus,
    getHistory,
    getApiStatus,
    pollTask,
  };
})();
